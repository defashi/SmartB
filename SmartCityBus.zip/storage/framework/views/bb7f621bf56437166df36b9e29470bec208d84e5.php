 <?php $__env->startSection('content'); ?>
  <h3>Admin Registration Page</h3>
  <?php echo Form::open(['url' => 'foo/bar']); ?>

  <div class="col-md-8">
    <div class="form-group">
    	<?php echo e(form::label('name', 'Name')); ?>

    	<?php echo e(form::text('name', '', ['class' => 'form-control', 'placeholder' => 'name'])); ?>

    </div>
    <div class="form-group">
    	<?php echo e(form::label('surname', 'Surname')); ?>

    	<?php echo e(form::text('surname', '', ['class' => 'form-control', 'placeholder' => 'surname'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(form::label('email', 'Email')); ?>

        <?php echo e(form::email('email', '', ['class' => 'form-control', 'placeholder' => 'email'])); ?>

    </div>
    <div class="form-group">
    	<?php echo e(form::label('password', 'Password')); ?>

    	<?php echo e(Form::password('password', ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(form::label('password', 'Confirm Password')); ?>

        <?php echo e(Form::password('password', ['class' => 'form-control'])); ?>

    </div>
    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

    </div>
  <?php echo Form::close(); ?>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>