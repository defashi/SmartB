 <?php $__env->startSection('content'); ?>
  <h3>Bus Registration Page</h3>
  <div class="col-md-8">
   <?php echo Form::open(['url' => 'foo/bar']); ?>

    <div class="form-group">
    	<?php echo e(form::label('plateNo', 'Plate Number')); ?>

    	<?php echo e(form::text('plateNo', '', ['class' => 'form-control', 'placeholder' => 'plate number'])); ?>

    </div>
    <div class="form-group">
    	<?php echo e(form::label('busowner', 'Bus Owner')); ?>

    	<?php echo e(Form::select('size', ['L' => 'dav', 'S' => 'tino'], null, ['placeholder' => 'choose bus owner'])); ?>

    </div>
    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

  <?php echo Form::close(); ?>

  </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>