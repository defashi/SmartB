 <?php $__env->startSection('content'); ?>
  <h3>Bus Owner Registration Page</h3>
  <div class="col-md-8">
   <?php echo Form::open(['url' => 'foo/bar']); ?>

   <div class="form-group">
    	<?php echo e(form::label('name', 'Name')); ?>

    	<?php echo e(form::text('name', '', ['class' => 'form-control', 'placeholder' => 'name'])); ?>

    </div>

     <div class="form-group">
      <?php echo e(form::label('phone', 'Phone number')); ?>

      <?php echo e(form::text('phone', null, ['class' => 'form-control', 'placeholder' => '+255*** number'])); ?>

    </div>

     <div class="form-group">
      <?php echo e(form::label('email', 'Email')); ?>

      <?php echo e(form::text('name', '', ['class' => 'form-control', 'placeholder' => ' name@gmail.com'])); ?>

    </div>

     <div class="form-group">
      <?php echo e(form::label('adress', 'Permanent Adress')); ?>

      <?php echo e(form::text('adress', null, ['class' => 'form-control', 'placeholder' => 'e.g. Sinza'])); ?>

    </div>
    
    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

  <?php echo Form::close(); ?>

  </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>