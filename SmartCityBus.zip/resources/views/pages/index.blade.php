@extends('layouts.appp')

 @section('content')
  

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><h4><b>Welcome To SmartBusCity</b></h4></div>

                <div class="panel-body">
                    <p>SmartBusCity is the system that allows a bus boarder with RFID card to swipe the RFID card in proximity with RFID card reader for trip payment in a particular city bus as well as being able to recharge his or her account with a mobile money service.</p><hr>
                </div>
            </div>
        </div>
    </div>
</div>


 @endsection